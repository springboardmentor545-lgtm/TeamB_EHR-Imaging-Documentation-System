# Multilingual Synthetic EHR Dataset Bundle

**This bundle contains three fully synthetic Electronic Health Record (EHR) datasets**
- 200,000 unique patients in each dataset
- Available in English, Spanish, and Russian
- Each dataset is adapted to the healthcare context and language of its target region

## What's Included

- `synthetic_ehr_dataset_uk.csv` (English, UK context)
- `ehr_sintetico_mexico.csv` (Spanish, Mexico context)
- `ehr_синтетика_россия_снг.csv` (Russian, Russia & CIS context)

Each dataset contains:
- 24 comprehensive EHR fields: demographics, diagnoses, medications, lab results, hospital, and more
- 100% synthetic and privacy-safe — no real patient data
- CSV format, easy to use in Python, R, Excel, AI/ML platforms

## Example Fields

| Field / Campo / Поле             | Example (EN) | Ejemplo (ES) | Пример (RU)       |
|----------------------------------|--------------|--------------|-------------------|
| patient_id / id_paciente / id_пациента | ...          | ...          | ...               |
| age / edad / возраст             | 45           | 45           | 45                |
| sex / sexo / пол                 | Male         | Masculino    | Мужской           |
| region / región / регион         | London       | CDMX         | Москва            |
| hospital / hospital / больница   | St. Thomas' Hospital | Hospital General de México | Городская больница №1 |
| ...                              | ...          | ...          | ...               |

## How to Use

1. **Download the desired dataset(s) from the bundle.**
2. **Open in your preferred tool:** Python, R, Excel, or data analysis platform.
3. **Each file is ready for AI, analytics, research, or prototyping.**

## Why buy this bundle?

- Fast access to realistic, multilingual EHR data for any healthcare AI, analytics, or educational project.
- Three distinct languages, each adapted to local healthcare terminology.
- Save time: instant download, no waiting, no data privacy concerns.

## License

See [LICENSE](LICENSE).

## Creator

EM- Siana BOX  
Contact: em@sianabox.com

---

## Español

Este paquete incluye tres datasets sintéticos de Historias Clínicas Electrónicas (EHR),  
cada uno con 200,000 pacientes, en **inglés, español y ruso**.  
Cada dataset es adecuado para proyectos de IA médica, analítica y desarrollo.

[El resto de instrucciones es igual — puedes adaptar según tu público.]
